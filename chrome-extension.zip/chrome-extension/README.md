## Setup
1. Clone repo locally
2. Go to chrome://extensions
3. Enable developer mode
4. Hit "Load Unpacked" and select the "chrome-extension" file in the project


## Usage
1. Press the extension icon
2. Press "EXPORT!"
3. Give access to MAL
4. Import downloaded file into Google Calender